#ifndef _LUDEC_H
#define _LUDEC_H
#endif